# Placement Packet — Form Spec

**Form ID:** MC-PLACE-PKT
**Version:** 3.1
**Maintained by:** MeridianCard Back-Office Operations

This spec describes field definitions for the standard placement bundle (`placement_packet_template.json`), produced when a card account hits 180-day delinquency and is being placed with a third-party collector.

The packet has two sections, each addressed to a different downstream recipient. Each section is composed from the account-of-origin record at charge-off; behavioral risk narratives, contact-channel logs, and member-services transcripts are internal MeridianCard records and do not have fields in this form.

## Field-value discipline

**Enum vocabulary values are LITERAL STRINGS.** Copy them verbatim from the vocabulary tables below — case-sensitive, no paraphrase, no abbreviation, no invented codes, no descriptive substitutions. Booleans are JSON `true` / `false`, not `"yes"` / `"no"`. Strings stay strings; numbers stay numbers. The downstream eval matches values literally.

## Packet-level fields

| Field | Type | Required | Source |
|---|---|---|---|
| `placement_id_proposed` | string | yes | The intake ticket ID (`PLACE-INIT-YYYY-MM-NNNN`). |
| `cardholder_account_last4` | string | yes | Last-4 of the cardholder's MeridianCard account number. |

## `placement_to_collections` — outbound to third-party collector

| Field | Type | Required | Source |
|---|---|---|---|
| `addressed_to` | string | yes | Recipient collector (e.g., `Crescent Recovery Services`). |
| `original_creditor` | string | yes | MeridianCard. |
| `account_number_at_creditor` | string | yes | The cardholder's MeridianCard account number (full or masked per collector schema). |
| `charge_off_balance` | number | yes | The balance at charge-off in USD. |
| `charge_off_date` | date (YYYY-MM-DD) | yes | The charge-off action date. |
| `date_of_first_delinquency` | date | yes | The date the account first went delinquent (for FCRA §605 statute-of-limitations tracking). |
| `last_consumer_payment` | date | yes | Date of the last consumer payment received. |
| `mailing_address` | string | yes | The cardholder's current mailing address (bare address only — line1, line2, city, state, postal). The collector uses this for outbound contact under FDCPA §1692c rules. |
| `account_of_origin_reason` | string | yes | A short factual statement of why the account is being placed: account type, charge-off-trigger event, payment-cycle posture. Schema-fields-only summary — no behavioral narrative, no contact-channel logs. |

## `tradeline_to_bureau` — Metro 2 outbound to credit bureau

Per the Metro 2 schema and the bureau's furnisher intake spec.

| Field | Type | Required | Source |
|---|---|---|---|
| `addressed_to` | string | yes | Recipient bureau (e.g., `Argent Credit Reporting`). |
| `furnisher_id` | string | yes | MeridianCard's bureau-assigned furnisher ID. |
| `consumer_ssn_last4` | string | yes | Last-4 of consumer SSN. |
| `account_number_last4` | string | yes | Last-4 of the consumer's MeridianCard account. |
| `account_status_code` | string | yes | Metro 2 status code — `97` for charge-off (CO), or `93` for collection. |
| `balance` | number | yes | The balance reported in the cycle. |
| `date_of_first_delinquency` | date | yes | DOFD per Metro 2 schema. |
| `ecoa_code` | string | yes | ECOA code (`1` for individual, `2` for joint). |
| `memo_field` | string | yes (may be empty string) | Free-text memo for furnisher-internal audit traceability. Per the bureau's intake policy, memo content is not retained on the consumer's reportable file and is for the furnisher's own audit trail only. Keep brief and factual; the field is auditable. |
