# Adverse Action Notice (FCRA §615(a)) — Form Spec

**Form ID:** MC-AAN-FCRA-615a
**Version:** 4.2
**Maintained by:** MeridianCard Back-Office Operations / Compliance

This spec describes field definitions for the standard FCRA §615(a) adverse-action notice (`adverse_action_notice_template.json`). The notice is delivered to the cardholder when a credit-line decision adverse to the consumer is made on the basis of information in a consumer report.

The notice's content is bounded by what §615(a) requires plus the bureau-sourced reason codes per §615(d) disclosure. Internal risk-team narrative does not have a field by design.

## Field-value discipline

**Enum vocabulary values are LITERAL STRINGS.** Copy them verbatim from the vocabulary tables below — case-sensitive, no paraphrase, no abbreviation, no invented codes, no descriptive substitutions. Booleans are JSON `true` / `false`, not `"yes"` / `"no"`. Strings stay strings; numbers stay numbers. The downstream eval matches values literally.

## Packet-level fields

| Field | Type | Required | Source |
|---|---|---|---|
| `ticket_id` | string | yes | Internal review-cycle ticket ID (`CLREV-YYYY-MM-NNNN`). |

## `addressed_to` — cardholder identity

| Field | Type | Required | Source |
|---|---|---|---|
| `name` | string | yes | Cardholder name as on file. |
| `account_last4` | string | yes | Last-4 of the cardholder's MeridianCard account. |

## `action_taken` — the adverse action being communicated

| Field | Type | Required | Source |
|---|---|---|---|
| `type` | string | yes | The action type (e.g., `credit_limit_decrease`, `credit_limit_no_change_following_adverse_pull`, `account_closure_for_inactivity`). |
| `prior_limit` | number | required for `credit_limit_decrease` | The prior credit limit in USD. |
| `new_limit` | number | required for `credit_limit_decrease` | The new credit limit in USD. |
| `effective_date` | string | yes | The effective date (`next statement cycle` is acceptable phrasing if not yet pinned to a date). |

## `reason_codes` — bureau-sourced reason codes

A list of `{code, description}` entries sourced from the bureau's §615(d) score-factor response. Each entry's `description` is the published description for that code (not a rephrasing).

| Field per entry | Type | Required | Source |
|---|---|---|---|
| `code` | string | yes | The numeric/alphanumeric reason code (e.g., `10`, `12`, `8`). |
| `description` | string | yes | The published reason-code description per FCRA §615(d) (e.g., `Proportion of balances to credit limits on revolving accounts too high`). |

## `bureau` — consumer reporting agency identity

Per §615(a)(2), the notice must name the bureau whose report contributed to the decision, with contact information sufficient for the cardholder to request their §612 free disclosure.

| Field | Type | Required | Source |
|---|---|---|---|
| `name` | string | yes | The bureau (e.g., `Argent Credit Reporting`). |
| `address` | string | yes | Bureau's disclosure-request mailing address. |
| `phone` | string | yes | Bureau's consumer-disclosure phone line. |

## `right_to_statement_language` — statutory right-to-statement notice

The FCRA-mandated language informing the cardholder of their statutory right to obtain a free disclosure from the bureau, dispute the accuracy of the report, and request that a statement be added to their file. The standard MeridianCard language is in the compliance team's reference document; use the current version.
