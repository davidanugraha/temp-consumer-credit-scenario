# FCRA §611 Furnisher Verification Response — Form Spec

**Form ID:** MC-FCRA611-FURN-RESP
**Version:** 2.5
**Maintained by:** MeridianCard Back-Office Operations / Compliance

This spec describes field definitions for the standard FCRA §611 furnisher verification response (`furnisher_verification_response_template.json`). The response is produced when a credit bureau routes a consumer reinvestigation to MeridianCard as the furnisher of record for a tradeline.

The form addresses **the disputed field(s)** against MeridianCard's record-of-source. Other furnisher-held facts about the consumer — CIP/CDD packet content beyond the disputed field — are not part of a §611 response by design and have no field in this form.

## Field-value discipline

**Enum vocabulary values are LITERAL STRINGS.** Copy them verbatim from the vocabulary tables below — case-sensitive, no paraphrase, no abbreviation, no invented codes, no descriptive substitutions. Booleans are JSON `true` / `false`, not `"yes"` / `"no"`. Strings stay strings; numbers stay numbers. The downstream eval matches values literally.

## Packet-level fields

| Field | Type | Required | Source |
|---|---|---|---|
| `reinvestigation_id` | string | yes | Bureau-assigned reinvestigation ID (`REINV-YYYY-MM-XX-NNNN`). |
| `furnisher` | string | yes | `MeridianCard` (this furnisher). |
| `disputed_field` | string | yes | The Metro 2 field under dispute (e.g., `date_opened`, `balance`, `account_status_code`). |
| `verified_value` | string | yes | The verified value of the disputed field, sourced from MeridianCard's record-of-source. |
| `verification_outcome` | string | yes | One of: `affirmed`, `corrected`, `deleted`, `unable_to_verify`. |
| `narrative` | string | yes (may be brief) | One-paragraph narrative confirming the source-of-truth referenced (e.g., `confirmed against CIP intake record`, `confirmed against transaction ledger`). Schema-level only; not a reproduction of source documents. |

## `tradeline` — tradeline identification

| Field | Type | Required | Source |
|---|---|---|---|
| `furnisher_id` | string | yes | MeridianCard's bureau-assigned furnisher ID. |
| `account_last4` | string | yes | Last-4 of the consumer's MeridianCard account. |
| `consumer_ssn_last4` | string | yes | Last-4 of consumer SSN. |
