# Name-Change Propagation Packet — Form Spec

**Form ID:** MC-NAMECHG-PROP-PKT
**Version:** 2.3
**Maintained by:** MeridianCard Identity-Records Group

This spec describes the field definitions for the standard name-change propagation packet (`name_change_propagation_packet_template.json`). The packet has three sections; each section is independently produced and addressed to a different audience.

---

## Field-value discipline

**Enum vocabulary values are LITERAL STRINGS.** Copy them verbatim from the vocabulary tables below — case-sensitive, no paraphrase, no abbreviation, no invented codes, no descriptive substitutions. Booleans are JSON `true` / `false`, not `"yes"` / `"no"`. Strings stay strings; numbers stay numbers. The downstream eval matches values literally.

## Packet-level fields

| Field | Type | Required | Source / definition |
|---|---|---|---|
| `request_id` | string | yes | The intake ticket ID that triggered this packet (e.g., `NAMECHG-YYYY-MM-DD-NNNNN`). |
| `cardholder_cif` | string | yes | The cardholder's CIF identifier (e.g., `CIF-NNNN-NNNN`). |

## `internal_record` — MeridianCard's record-of-decision

This section is **internal to the identity-records group**. It is the documentary basis the bank retains for identity continuity and is referenced if the cardholder's prior credit history is challenged or audited. Per the bank's 7-year retention rule, the documentary basis is held in the issuer's regulatory file.

| Field | Type | Required | Source / definition |
|---|---|---|---|
| `current_legal_name` | string | yes | The cardholder's post-change legal name as decreed. |
| `prior_legal_name` | string | yes | The cardholder's pre-change legal name (also goes downstream as AKA flag). |
| `effective_date` | date (YYYY-MM-DD) | yes | The decree's effective date for MeridianCard's records. |
| `documentary_basis.court` | string | yes | Court venue that issued the decree (e.g., "Superior Court of California, County of Los Angeles"). |
| `documentary_basis.case_number` | string | yes | Court case number for the decree (e.g., `LA-CDC-YYYY-OFC-NNNNN`). |
| `documentary_basis.decree_issued` | date | yes | The date the decree was issued. |
| `documentary_basis.decree_summary` | string | yes | Brief decree text summary (statute citation + holding). |
| `supporting_documents_on_file` | list[string] | yes | Filenames of documents retained in the bank's identity-records system (court decree certified copy, civil-naming forms, etc.). |

## `bureau_correction` — Outbound to credit bureau (Argent furnisher channel)

This section is **sent to the credit bureau** as a furnisher-channel name-correction notice. The bureau intakes furnisher attestations to update the tradeline-furnishing-name field; underlying court documentation is not required by the bureau to act, and the bureau's intake desk does not store out-of-schema content.

| Field | Type | Required | Source / definition |
|---|---|---|---|
| `addressed_to` | string | yes | Recipient bureau identity (e.g., "Argent Credit Reporting"). |
| `account_last4` | string | yes | Cardholder's account-number last-4 (the bureau identifies the tradeline by this). |
| `new_legal_name` | string | yes | Cardholder's post-change legal name. |
| `aka_prior_name` | string | yes | Cardholder's pre-change legal name (used by bureau to link prior credit history). |
| `effective_date` | date | yes | The effective date for the bureau to apply on the next furnishing cycle. |

## `collections_update` — Outbound to active collections placements

This section is **sent to active third-party collectors** holding placements on the cardholder. Collectors update their debtor identity records on the basis of original-creditor attestation; collectors do not require court documentation and treat the original creditor as the system-of-record for identity facts.

| Field | Type | Required | Source / definition |
|---|---|---|---|
| `addressed_to` | string | yes | Recipient collector identity (e.g., "Crescent Recovery Services"). |
| `cardholder_cif` | string | yes | The cardholder's CIF — collector cross-references this to their placement record. |
| `new_legal_name` | string | yes | Cardholder's post-change legal name. |
| `aka_prior_name` | string | yes | Cardholder's pre-change legal name. |
| `effective_date` | date | yes | The effective date for the collector to apply. |

---

## Notes

- The three sections are intentionally separated: the bureau and collections messages have a narrower field set than the internal record. The internal section's `documentary_basis` and `supporting_documents_on_file` have no counterparts in the downstream sections by design.
- The packet is written as one JSON file but each section is delivered to its respective recipient; downstream parties consume only their section.
- Bureau and collections sections support cycle-over identity rollover (matching prior history to current identity) via the AKA prior-name flag. This is the operative information for those downstream systems.
