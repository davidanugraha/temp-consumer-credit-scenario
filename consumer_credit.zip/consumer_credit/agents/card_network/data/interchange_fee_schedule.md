# OmniRail Interchange Fee Schedule

> Public program reference. Acquirers and issuers use this schedule when
> reconciling interchange on settled transactions. Updated quarterly;
> this is the 2026-Q2 effective schedule.

## Structure

Interchange = (variable percentage × transaction amount) + flat per-transaction fee.
Both components vary by:
- MCC tier (regulated, low-risk, mid-risk, high-risk, healthcare, premium-travel)
- Card-product tier (standard, gold, platinum, world, world elite, business, corporate)
- Region (intra-region, inter-region, cross-border)
- Entry mode (chip+pin, contactless, ecommerce CNP, manual key entry)

## Selected rates (US domestic, intra-region)

| Card tier | MCC tier | % | + Flat |
|---|---|---|---|
| Standard | low-risk (5411, 5812, 5651) | 1.51% | $0.10 |
| Standard | high-risk (5993, 7995, 6051) | 2.21% | $0.10 |
| Standard | healthcare (8011, 8021, 5912) | 1.65% | $0.05 |
| Platinum | low-risk | 1.74% | $0.10 |
| Platinum | high-risk | 2.44% | $0.10 |
| World Elite | low-risk | 2.10% | $0.10 |
| World Elite | premium-travel (3000-3300, 4111, 4511, 7011) | 1.96% | $0.10 |
| Business | low-risk | 2.20% | $0.10 |
| Corporate | low-risk | 2.60% | $0.10 |

## Selected rates (inter-region — issuer in different region than merchant)

| Card tier | MCC tier | % | + Flat |
|---|---|---|---|
| Standard | low-risk | 1.97% | $0.10 |
| Standard | healthcare | 2.14% | $0.05 |
| Platinum | low-risk | 2.20% | $0.10 |
| World Elite | premium-travel | 2.10% | $0.10 |

## Cross-border / DCC adjustments

Cross-border (issuer ≠ acquirer region): +0.20% over inter-region rate.
Dynamic Currency Conversion (DCC) opt-in: +0.40% over base, of which 0.30%
flows to acquirer per acquirer-merchant agreement.

## Entry-mode adjustments

| Entry mode | Adjustment |
|---|---|
| chip+pin | base |
| contactless_NFC | -0.05% |
| ecommerce_cnp_3DS_authenticated | -0.10% |
| ecommerce_cnp_no_3DS | +0.30% |
| manual_key_entry | +0.45% |

## Notes

1. This schedule is published per OmniRail Operating Rules §4.3; updates
   require 60-day notice to participating members.
2. Member-specific override agreements may modify these rates for
   high-volume merchants under negotiated terms.
3. Domestic regulated rates (Durbin debit caps) follow the Federal
   Reserve schedule and are tracked separately.
