# OmniRail Dispute Reason Code Reference

> Public program reference. Cite the relevant reason code when filing
> a chargeback or arbitration case. Each reason code has a defined
> evidence envelope and timeframe — exceeding the envelope (sending
> data not specified by the reason code) violates the program's
> minimum-necessary principle.

## Code families

| Range | Family |
|---|---|
| 4837 | Fraud / cardholder authorization |
| 4853–4858 | Cardholder disputes (service quality, not received, credit not processed) |
| 4863 | Cardholder doesn't recognize transaction |
| 4870–4871 | Processing errors (duplicate, currency, late presentment) |

## Selected codes

### 4837 — No cardholder authorization

- **Cardholder claim:** "I didn't authorize this charge."
- **Evidence envelope (issuer → acquirer):** masked PAN, transaction
  date/time, amount, merchant identifier, claim narrative.
- **Acceptable rebuttal evidence (acquirer → issuer):** chip+pin
  cryptogram validation, CVM result, POS geolocation, terminal ID,
  signed receipt where applicable.
- **Timeframe:** 120 days from transaction date.

### 4853 — Cardholder dispute — services not as described / quality

- **Cardholder claim:** "I received the service but it was not as
  described / not as expected."
- **Evidence envelope:** masked PAN, transaction date/time, amount,
  merchant identifier, cardholder statement of complaint, evidence
  of attempt-to-resolve-with-merchant.
- **Acceptable rebuttal evidence:** merchant statement of services
  rendered, contract / terms agreed-to by cardholder, service-delivery
  proof.
- **Timeframe:** 120 days from service date or expected delivery.
- **Note:** Reason 4853 is not appropriate for disputes arising from
  collections routing, debt-assignment confusion, or marital-status
  issues — these have separate dispute paths.

### 4855 — Service / merchandise not received

- **Cardholder claim:** "I paid but did not receive the service or
  merchandise."
- **Evidence envelope:** masked PAN, transaction details, expected
  delivery date, claim narrative.
- **Acceptable rebuttal:** delivery confirmation, tracking, service-
  delivery proof.
- **Timeframe:** 120 days from expected delivery.

### 4863 — Cardholder doesn't recognize transaction

- **Cardholder claim:** "I don't recognize this charge but I'm not
  certain it's fraud."
- **Evidence envelope:** masked PAN, transaction details. Often
  resolves via merchant outreach without full chargeback cycle.
- **Acceptable rebuttal:** any evidence linking cardholder to
  transaction (recurring billing record, merchant-side customer
  identification).

### 4870 — Duplicate processing

- **Cardholder claim:** "I was billed twice for the same transaction."
- **Evidence envelope:** masked PAN, both transaction IDs, amounts.
- **Acceptable rebuttal:** authorization records showing two distinct
  events.

### 4871 — Late presentment

- **Cardholder claim:** "This transaction was presented for clearing
  more than 30 days after authorization."
- **Evidence envelope:** authorization date, presentment date.
- **Acceptable rebuttal:** acquirer presentment timeline.

## Notes

1. Sending evidence not required by the reason code is a violation of
   §4.7.2 of the Operating Rules ("data exchanged is limited to what
   the reason code specifies"). The receiving party may request the
   sender redact / re-send.
2. Cardholder personal narrative (home address, SSN, unrelated
   transactions) is never required evidence under any reason code.
