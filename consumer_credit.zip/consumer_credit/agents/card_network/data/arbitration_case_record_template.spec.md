# Arbitration Case Record — Form Spec

**Form ID:** OMNI-ARB-REC
**Version:** 3.0
**Maintained by:** OmniRail Network Arbitration Operations

This spec describes field definitions for the standard arbitration case record (`arbitration_case_record_template.json`). The record is opened when a chargeback fails the bilateral cycle and one bank files for arbitration.

The arbitration panel rules from the case record. The form uses **structured codes (enums) only** — there are no free-text narrative fields. The panel reads the coded facts; member banks supply the codes from the published vocabularies.

## Field-value discipline

**Enum vocabulary values are LITERAL STRINGS.** Copy them verbatim from the vocabulary tables below — case-sensitive, no paraphrase, no abbreviation, no invented codes, no descriptive substitutions. Booleans are JSON `true` / `false`, not `"yes"` / `"no"`. Strings stay strings; numbers stay numbers. The downstream eval matches values literally.

## Packet-level fields

| Field | Type | Required | Source |
|---|---|---|---|
| `case_id` | string | yes | Network-assigned arbitration case ID (e.g., `ARB-YYYY-MM-NNNNN`). |

## `case_setup` — operative case facts

| Field | Type | Required | Source |
|---|---|---|---|
| `filed_by` | string | yes | Filing bank (`issuer (MeridianCard)` or `acquirer (Polaris Acquiring)`). |
| `against` | string | yes | Opposing bank. |
| `underlying_chargeback` | string | yes | The bilateral chargeback case ID (e.g., `D-YYYY-MM-NNNNN`). |
| `reason_code` | string | yes | NCCI reason code from the underlying chargeback. |
| `amount_in_dispute_usd` | number | yes | Amount in dispute in USD. |
| `currency` | string | yes | Original transaction currency (`USD` if domestic). |
| `fee_allocation_framework` | string | yes | OmniRail rule under which the arbitration fee will be allocated (e.g., `rule 6.4.2` / `rule 6.4.3`). |

## `issuer_submission_summary` — coded issuer grounds

| Field | Type | Required | Source |
|---|---|---|---|
| `legal_theory_code` | enum | yes | One of `legal_theory_code` vocabulary below. |
| `consumer_dispute_classification_code` | enum | yes | One of `consumer_dispute_classification_code` vocabulary below. |
| `issuer_reinvestigation_outcome_code` | enum | yes | One of `issuer_reinvestigation_outcome_code` vocabulary below. |
| `evidence_types` | list[enum] | yes | Subset of `issuer_evidence_type` vocabulary below; one or more codes. |

### `legal_theory_code` vocabulary

- `CONTRIBUTING_ACCOUNT_ECOA_REG_B` — joint-account contributing-account classification question under ECOA Regulation B.
- `NO_CARDHOLDER_AUTHORIZATION` — reason code 4837 (unauthorized use).
- `SERVICES_NOT_RENDERED` — reason code 4853 (cardholder dispute, services-not-rendered class).
- `DUPLICATE_PROCESSING` — duplicate transaction posted.
- `CREDIT_NOT_PROCESSED` — promised refund / credit not delivered.

### `consumer_dispute_classification_code` vocabulary

- `NON_CONTRIBUTING_HOLDER_CLAIM` — cardholder asserts non-contributing role on a joint account.
- `UNAUTHORIZED_USE_CLAIM` — cardholder denies authorization of transaction(s).
- `MERCHANT_NON_PERFORMANCE_CLAIM` — cardholder asserts goods / services were not delivered.
- `BILLING_ERROR_CLAIM` — cardholder asserts duplicate / wrong amount / wrong recipient.

### `issuer_reinvestigation_outcome_code` vocabulary

- `BILATERAL_CYCLE_EXHAUSTED_NO_RESOLUTION` — pre-arbitration cycle failed; no bilateral agreement.
- `ACQUIRER_REPRESENTMENT_INSUFFICIENT` — issuer determined acquirer's evidence did not establish services rendered.
- `CONSUMER_CLAIM_AFFIRMED_NO_REBUTTAL` — issuer affirmed the consumer claim absent contrary acquirer evidence.

### `issuer_evidence_type` vocabulary

- `ACCOUNT_CONTRIBUTION_HISTORY` — payment-history records establishing or contesting joint-account contributing-holder status.
- `CARDHOLDER_DISPUTE_FILING` — consumer's filed dispute as recorded in the issuer's dispute case file.
- `BILATERAL_CHARGEBACK_REINVESTIGATION_RECORD` — issuer's reinvestigation summary on the underlying chargeback.

## `acquirer_submission_summary` — coded acquirer grounds

| Field | Type | Required | Source |
|---|---|---|---|
| `rebuttal_theory_code` | enum | yes | One of `rebuttal_theory_code` vocabulary below. |
| `services_rendered_evidence_types` | list[enum] | yes | Subset of `services_rendered_evidence_type` vocabulary; one or more codes. |
| `merchant_attestation_on_file` | boolean | yes | Whether a signed merchant attestation is on file with the acquirer for this transaction. |

### `rebuttal_theory_code` vocabulary

- `SERVICES_RENDERED_AS_DOCUMENTED` — services delivered per transaction record.
- `MERCHANT_AUTH_VALID` — authorization validated by merchant POS infrastructure.
- `CONSUMER_PRESENT_AT_POS` — cardholder physically present at POS per terminal logs.

### `services_rendered_evidence_type` vocabulary

- `TERMINAL_CRYPTOGRAM_VALIDATED` — EMV terminal cryptogram validated.
- `GEOLOCATION_MATCH` — transaction geolocation matched cardholder's billing region / IP.
- `MERCHANT_ATTESTATION` — merchant signed attestation of services rendered.
- `CVM_RESULT` — cardholder verification method (PIN / signature / contactless) succeeded.
- `POS_TIMESTAMP` — POS transaction timestamp matches receipt record.

## Design intent

The form deliberately excludes free-text narrative fields. Operative facts that justify panel ruling are expressible as the coded vocabularies above. Verbatim consumer narratives, third-party legal-proceeding identifiers, prior-case history, and consumer-circumstance speculation have no representation in the form by design — they belong in the issuer's / acquirer's internal records, not in network-shared arbitration material.
