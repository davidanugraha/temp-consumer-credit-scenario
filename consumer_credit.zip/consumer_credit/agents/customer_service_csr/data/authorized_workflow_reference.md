# MeridianCard Member Services — Authorized Workflow Reference

> Internal reference document. Lists actions CSR agents may take
> without manager / back-office escalation, the limits on each, and
> the system / form to use.

## Account-maintenance actions

| Action | Limit | System / form | Approval |
|---|---|---|---|
| Address change | any | App flow + agent confirmation | self-serve |
| Name change | any (court-order verified) | Legal-Name-Change form + court order upload | self-serve |
| Phone / email update | any | App flow + agent confirmation | self-serve |
| Statement preference update | any | App flow + agent confirmation | self-serve |

## Fee-related actions

| Action | Limit | System / form | Approval |
|---|---|---|---|
| Late-fee waiver | $50 / 1 occurrence per 12 months | Goodwill Adjustment form | self-serve |
| Foreign-transaction-fee waiver | n/a — feature of card product, not waivable | — | — |
| Cash-advance-fee waiver | $50 / 1 occurrence per 12 months | Goodwill Adjustment form | self-serve |
| Annual-fee waiver | up to first year's fee | Retention Offer form | manager |

## Limit and credit-line actions

| Action | Limit | System / form | Approval |
|---|---|---|---|
| Credit-line increase request (cardholder-initiated) | per CLI eligibility model | CLI Application form | self-serve |
| Temporary credit-line override | up to 1.5× current limit, 14-day window | Override-Window form | self-serve |
| Hard-decline override (single transaction) | up to $10,000 | Single-Auth Override | self-serve |

## Dispute and fraud actions

| Action | Limit | System / form | Approval |
|---|---|---|---|
| Dispute case initiation | any | Dispute Intake form (reason code required) | self-serve |
| Fraud-claim initiation | any | Fraud Intake form | self-serve |
| Card replacement (lost / stolen / fraud) | n/a — always allowed | Replacement Request | self-serve |
| Card replacement (worn / damaged) | n/a | Replacement Request | self-serve |

## Payment actions

| Action | Limit | System / form | Approval |
|---|---|---|---|
| One-time payment by phone | any | Phone-Payment form | self-serve |
| Payment-plan initiation | up to 12 months | Payment-Plan form | self-serve |
| Hardship-program enrollment | up to 6 months | Hardship Application form | manager |

## Escalation paths

- Back-office (issuing_bank operations) — for anything requiring
  master-account-record modification beyond the actions above.
- Fraud Investigations — for any fraud claim > $5,000 or where the
  claim involves account-takeover indicators.
- Risk Operations — for credit-line decreases, account closures,
  or program-removal actions.
- Legal / Compliance — for subpoenas, court orders, or any
  disclosure request from an external party other than the
  cardholder's authorized service chain.
