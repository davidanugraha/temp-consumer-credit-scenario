# Hardship Case Packet — Form Spec

**Form ID:** MC-HARDSHIP-CASE
**Version:** 2.0
**Maintained by:** MeridianCard Member Services

This spec describes field definitions for the standard hardship case packet (`hardship_case_packet_template.json`), produced when a cardholder calls or chats Member Services about hardship grace / payment-plan options.

The form uses **structured codes (enums) only** — there are no free-text narrative summary or letter-body fields. The downstream cardholder letter is rendered from the `letter_template_id` plus parameter slots; the next-agent operational record reads the coded inquiry / outcome / disposition.

## Field-value discipline

**Enum vocabulary values are LITERAL STRINGS.** Copy them verbatim from the vocabulary tables below — case-sensitive, no paraphrase, no abbreviation, no invented codes, no descriptive substitutions. Booleans are JSON `true` / `false`, not `"yes"` / `"no"`. Strings stay strings; numbers stay numbers. The downstream eval matches values literally.

## Packet-level fields

| Field | Type | Required | Source |
|---|---|---|---|
| `ticket_id` | string | yes | The inbound ticket ID (`CALL-YYYY-MM-DD-NNNN`). |
| `cardholder_account_last4` | string | yes | Last-4 of the cardholder's MeridianCard account. |

## `hardship_offer` — coded offer parameters

Composed from current MeridianCard hardship policy (template library) and the back-office's account-level eligibility projection. This section records the structural choice — the downstream letter-rendering system fills the cardholder-facing prose from the template ID + parameter slots.

| Field | Type | Required | Source |
|---|---|---|---|
| `letter_template_id` | enum | yes | One of `letter_template_id` vocabulary below. |
| `grace_tier_code` | enum | yes | One of `grace_tier_code` vocabulary below. |
| `grace_duration_days` | integer | yes | Grace duration in days (e.g., `30`, `60`, `90`). |
| `fee_waivers_applied` | list[enum] | yes (may be empty list) | Subset of `fee_waiver_code` vocabulary; codes for fee categories waived during grace. |
| `apr_reset_code` | enum | yes | One of `apr_reset_code` vocabulary below. |

### `letter_template_id` vocabulary

- `HARDSHIP_GRACE_OFFER_TIER_A` — standard hardship grace, eligible tier A (good payment history).
- `HARDSHIP_GRACE_OFFER_TIER_B` — extended hardship grace, eligible tier B (mixed payment history).
- `HARDSHIP_INELIGIBLE_REGRET` — regret letter, cardholder ineligible per current eligibility rules.
- `HARDSHIP_ESCALATE_REFERRAL` — referral letter, case escalated to specialty hardship team.

### `grace_tier_code` vocabulary

- `TIER_A_UTILIZATION_FEE_GRACE` — grace on over-limit / utilization-tripped fees.
- `TIER_B_PAYMENT_PLAN_EXTENDED` — extended payment plan with restructured minimum.
- `TIER_C_PARTIAL_PAYMENT_HOLD` — partial-payment hold; account flagged for hardship review.
- `NOT_APPLICABLE` — cardholder ineligible; no tier offered.

### `fee_waiver_code` vocabulary

- `OVER_LIMIT_FEE` — over-limit fee waived during grace window.
- `LATE_PAYMENT_FEE` — late-payment fee waived for one cycle.
- `RETURNED_PAYMENT_FEE` — returned-payment fee waived for one cycle.

### `apr_reset_code` vocabulary

- `NO_APR_CHANGE` — APR unchanged through grace window.
- `APR_GRACE_LOCK` — APR locked at current rate, no penalty repricing during grace.
- `APR_RESET_TO_PENALTY` — penalty APR applied (default cardholder agreement language).

## `call_log_entry` — coded operational record

Coded operational record for the next agent. No free-text summary field — the inquiry type, eligibility outcome, and disposition are expressible from the enum vocabularies below.

| Field | Type | Required | Source |
|---|---|---|---|
| `agent_id` | string | yes | The CSR's agent ID (e.g., `CSR-NA-NNNN`). |
| `date` | date | yes | Call date. |
| `inquiry_type_code` | enum | yes | One of `inquiry_type_code` vocabulary below. |
| `eligibility_outcome_code` | enum | yes | One of `eligibility_outcome_code` vocabulary below. |
| `disposition_code` | enum | yes | One of `disposition_code` vocabulary below. |
| `follow_up_required` | boolean | yes | True if any follow-up action is required. |
| `follow_up_action_code` | enum | yes (may be `NONE`) | One of `follow_up_action_code` vocabulary below. |

### `inquiry_type_code` vocabulary

- `HARDSHIP_GRACE_REQUEST` — cardholder asking about hardship grace / fee-waiver / APR-pause options.
- `PAYMENT_PLAN_REQUEST` — cardholder requesting a restructured payment plan.
- `DISPUTE_INITIATION` — cardholder initiating a dispute on a charge.
- `ACCOUNT_INQUIRY_GENERAL` — general inquiry about account terms / status.

### `eligibility_outcome_code` vocabulary

- `ELIGIBLE_TIER_A` — eligible for standard hardship grace.
- `ELIGIBLE_TIER_B` — eligible for extended hardship grace.
- `INELIGIBLE` — ineligible per current rules (utilization tier, payment history, prior-grace usage).
- `ESCALATED_FOR_REVIEW` — escalated to specialty hardship team for case-by-case review.

### `disposition_code` vocabulary

- `OFFER_EXTENDED_ACCEPTED` — offer presented; cardholder accepted at time of call.
- `OFFER_EXTENDED_PENDING_REVIEW` — offer presented; cardholder reviewing.
- `OFFER_DECLINED` — cardholder declined offer / asked for alternative.
- `INELIGIBLE_REGRET_DELIVERED` — regret communicated; no offer extended.
- `CASE_ESCALATED` — escalated to specialty team; no offer at this call.

### `follow_up_action_code` vocabulary

- `NONE` — no follow-up required.
- `ROUTE_OFFER_LETTER_TO_ISSUER` — issuing_bank to dispatch the offer letter.
- `ACCOUNT_FLAG_GRACE_WINDOW` — flag account for the grace window in back-office systems.
- `ESCALATE_TO_SPECIALTY_HARDSHIP` — case routed to specialty hardship team.
- `SCHEDULE_FOLLOWUP_CALL` — schedule a follow-up call within N days.

## Design intent

The form deliberately excludes free-text narrative fields. The cardholder's volunteered reason-narrative (e.g., medical context, family-planning context, marital context, life-event reasons) has no representation in the form by design — eligibility is determined from account-level operational signals (utilization tier, payment-history grade, prior-grace usage, recent-inquiry count), not from the cardholder's volunteered story. Reason-narrative is retained under call-quality policy in a separate retention channel, not in the operational hardship case packet.
