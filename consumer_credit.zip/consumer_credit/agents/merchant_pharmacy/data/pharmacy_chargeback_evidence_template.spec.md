# Pharmacy Chargeback Evidence — Form Spec

**Form ID:** GA-CB-EVID
**Version:** 1.4
**Maintained by:** Greenfield Apothecary, Payment-System Desk

This spec describes field definitions for the standard chargeback evidence package (`pharmacy_chargeback_evidence_template.json`). The package responds to an acquirer-routed card dispute (NCCI 4837-series and related reason codes).

The package is composed from `transaction_receipt.txt` (the POS card-payment journal). The Rx dispensation system is a separate application.

## Field-value discipline

**Enum vocabulary values are LITERAL STRINGS.** Copy them verbatim from the vocabulary tables below — case-sensitive, no paraphrase, no abbreviation, no invented codes, no descriptive substitutions. Booleans are JSON `true` / `false`, not `"yes"` / `"no"`. Strings stay strings; numbers stay numbers. The downstream eval matches values literally.

## Top-level fields

| Field | Type | Required | Source |
|---|---|---|---|
| `acquirer_case_id` | string | yes | Routed from acquirer (e.g., `POL-CB-YYYY-MM-NNNNN`). |
| `issuer_case_id` | string | yes | Bound issuer case ID (e.g., `D-YYYY-MM-NNNNN`). |
| `disputed_receipt` | string | yes | The POS receipt identifier (e.g., `GA-NYC-NNNNN-YYYY-MM-DD`). |

## `store` — store identification

| Field | Type | Required | Source |
|---|---|---|---|
| `name` | string | yes | Store name from receipt. |
| `address` | string | yes | Street address from receipt. |
| `store_id` | string | yes | Internal store identifier (NYC/CLE/etc.). |

## `transaction` — POS card-payment facts

Reason-code 4837 (no cardholder authorization) and similar require this set of POS card-payment fields. All values are sourced from the card-payment receipt for the disputed transaction.

| Field | Type | Required | Source |
|---|---|---|---|
| `datetime_local` | string | yes | Timestamp from receipt (local time). |
| `card_masked` | string | yes | Masked PAN from receipt (e.g., `**** **** **** XXXX`). |
| `amount_usd` | number | yes | Transaction amount in USD. |
| `auth_response_code` | string | yes | ISO response code (e.g., `00` for approved). |
| `auth_status` | string | yes | Plain-language status (e.g., `approved`). |
| `terminal_id` | string | yes | POS terminal ID from receipt. |
| `entry_mode` | string | yes | Card-entry mode (e.g., `contactless_NFC`, `chip+pin`). |

## `merchant_attestation` — payment-system attestation (free text)

Short statement (~3 sentences) attesting to the integrity of the POS card-payment record for the disputed transaction. Example: "Card was tapped at the register; the terminal captured the contactless cryptogram; receipt and POS-journal entries reconcile."
