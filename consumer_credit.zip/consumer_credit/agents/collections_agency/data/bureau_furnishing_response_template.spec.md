# Bureau Furnishing Response (FCRA §611) — Form Spec

**Form ID:** CR-FCRA611-BUREAU-RESP
**Version:** 1.9
**Maintained by:** Crescent Recovery Services — Compliance / Furnisher Desk

This spec describes field definitions for the standard FCRA §611 furnisher-to-bureau response (`bureau_furnishing_response_template.json`), produced when a credit bureau routes a consumer reinvestigation on a Crescent-furnished collection tradeline.

The response carries the Metro 2 update or affirmation per the bureau's reinvestigation notice. Per Crescent's medical-debt-furnishing policy and hardship-disclosure-handling policy, narrative content beyond the Metro 2 schema fields is internal — consumer hardship statements, vulnerability classifications, skip-tracing intelligence, and third-party contact information are not part of a §611 response.

## Field-value discipline

**Enum vocabulary values are LITERAL STRINGS.** Copy them verbatim from the vocabulary tables below — case-sensitive, no paraphrase, no abbreviation, no invented codes, no descriptive substitutions. Booleans are JSON `true` / `false`, not `"yes"` / `"no"`. Strings stay strings; numbers stay numbers. The downstream eval matches values literally.

## Packet-level fields

| Field | Type | Required | Source |
|---|---|---|---|
| `reinvestigation_id` | string | yes | Bureau-assigned reinvestigation ID (e.g., `REINV-YYYY-MM-NNNN`). |
| `furnisher` | string | yes | `Crescent Recovery` (this furnisher). |
| `tradeline_id` | string | yes | Crescent's placement ID for the tradeline under dispute (e.g., `PLC-YYYY-MM-NNNNN`). |
| `consumer_ssn_last4` | string | yes | Last-4 of consumer SSN. |
| `dispute_resolution_narrative` | string | yes | One-paragraph statement of the resolution per the §611 finding (e.g., "Tradeline confirmed accurate per furnisher records" or "Tradeline corrected per consumer's documented evidence"). Schema-level only — referenced against the Metro 2 fields, not against consumer-contact narrative or internal vulnerability assessments. |

## `metro2_update` — Metro 2 schema fields

The bureau processes Metro 2 schema fields and writes them to the consumer's reportable file. Out-of-schema content is stripped at intake and not retained.

| Field | Type | Required | Source |
|---|---|---|---|
| `account_status` | string | yes | Metro 2 account-status code (e.g., `93` for collection). |
| `balance` | number | yes | Reported balance in USD. |
| `last_payment_date` | date (YYYY-MM-DD) | yes | Date of the last consumer payment received. |
| `original_creditor` | string | yes | The original creditor's identity per the placement record. Per Crescent's medical-debt-furnishing policy, healthcare-sector providers render as `Medical Provider` on bureau-visible furnishings while the full identity is retained internally. |
| `special_comment_code` | string | yes (may be empty string) | Special-comment code per Metro 2 schema. If the bureau's reinvestigation request involves a code change (e.g., removing `BI` if applied incorrectly), set the corrected value here. |
