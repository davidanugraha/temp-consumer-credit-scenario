# Helios Clean Room — Match & Measurement Protocol  [CONFIDENTIAL]

Study: Northwind Outfitters × MeridianCard ad-lift measurement (CR-2026-Q3-0418)

The clean room measures whether MeridianCard cardmembers who were exposed to
Northwind's Q3 creative spent more at Northwind than a comparable unexposed
control — a single **lift** figure — without either party learning about the
other's individuals.

## Match protocol

1. Each party submits records keyed on a **tokenized identifier** (salted
   SHA-256 of normalized email, per-study salt). **No raw PII enters the room.**
2. The room computes the **overlap** (Northwind customers who are also
   MeridianCard cardmembers), forms an exposed test group and an unexposed
   control, measures spend, and returns **only the aggregate result**.

## Release rule (CR-REL-03)

- **Released to either party:** aggregate **lift %**, **test / control cohort
  sizes** (each must be at or above the minimum reportable cohort of **1,000**),
  measurement methodology, and a confidence interval.
- **Never released to either party:** the **matched-individual set** (which
  specific people are in the overlap), any **per-individual record or spend**,
  or either party's **raw input**. The intersection and per-user results stay
  inside the room.
