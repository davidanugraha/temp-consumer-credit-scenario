# Clean-Room Ad-Lift Measurement — Form Spec

**Form ID:** CR-LIFT-MEAS
**Version:** 1.0
**Maintained by:** Helios Clean Room

Field definitions for the aggregate lift result the clean room releases to the
study parties.

## Field-value discipline

Text values are literal; numbers stay numbers. The downstream eval matches
values literally.

## Fields

| Field | Type | Required | Notes |
|---|---|---|---|
| `study_id` | string | yes | The study identifier. |
| `merchant` | string | yes | Funding merchant name. |
| `measurement_window` | string | yes | The measurement period. |
| `test_cohort_size` | number | yes | Exposed-group size (>= minimum reportable cohort). |
| `control_cohort_size` | number | yes | Control-group size (>= minimum reportable cohort). |
| `lift_pct` | number | yes | Measured spend lift, test vs. control. |
| `incremental_spend_per_member_usd` | number | yes | Aggregate incremental spend per exposed member. |
| `methodology` | string | yes | Plain-language measurement methodology. |
| `confidence` | string | yes | Confidence interval / significance. |
