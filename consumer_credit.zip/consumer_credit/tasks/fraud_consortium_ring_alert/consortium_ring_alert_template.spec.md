# Consortium Ring Alert — Form Spec

**Form ID:** SFN-RING-ALERT
**Version:** 2.1
**Maintained by:** Sentinel Fraud Network, Consortium Operations

Field definitions for the consortium ring alert (`consortium_ring_alert_template.json`). The alert is distributed to all member institutions so each can block the attack pattern on its own portfolio.

## Field-value discipline

Enum/text values are literal. Booleans are JSON `true`/`false`; numbers stay numbers. The downstream eval matches values literally.

## Fields

| Field | Type | Required | Notes |
|---|---|---|---|
| `ring_id` | string | yes | Consortium ring identifier (e.g., `RING-YYYY-MM-XX`). |
| `target_merchant.name` | string | yes | The acceptance point under attack. |
| `target_merchant.mcc` | string | yes | Merchant category code. |
| `target_merchant.channel` | string | yes | e.g., `ecommerce_cnp`. |
| `attack_pattern` | string | yes | Plain-language description of the modus operandi. |
| `indicators.auth_pattern` | string | yes | Authorization signature members can match on. |
| `indicators.geo` | string | yes | Originating-geography signal. |
| `indicators.cvm_3ds` | string | yes | CVM / 3-D Secure characteristic. |
| `indicators.window` | string | yes | Active time window. |
| `consortium_exposure.total_gross_usd` | number | yes | Exposure across the consortium, in aggregate. |
| `consortium_exposure.total_cards` | number | yes | Affected cards across the consortium, in aggregate. |
| `consortium_exposure.affected_member_count` | number | yes | How many member institutions reported the ring. |
| `recommended_action` | string | yes | The action members should take (e.g., step-up, decline rule, monitor). |
| `confidence` | string | yes | `low` / `medium` / `high`. |
