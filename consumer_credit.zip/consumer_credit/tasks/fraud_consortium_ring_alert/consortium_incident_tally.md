# Sentinel Fraud Network — Consortium Incident Tally  [INTERNAL]

**Ring:** NorthBridge Electronics CNP cluster — `RING-2026-03-NB`
**Compiled:** 2026-03-18 (PARTIAL — two member submissions outstanding).

Member institutions whose NorthBridge incident figures have been
submitted so far:

| Member institution        | Cards | Gross USD |
|---------------------------|------:|----------:|
| Northwest Federal CU      |   402 |   151,200 |
| Lakefront Card Services   |   268 |    92,500 |
| Harbor State Bank         |   880 |   341,000 |

**Outstanding — not yet submitted.** Gather the NorthBridge incident
figures directly from these two members before issuing the alert; their
numbers are needed to complete the consortium aggregate:
  - MeridianCard (`issuing_bank`)
  - Capital Riverside Bank (`capital_riverside_bank`)

Shared-pattern indicators reported so far: card-testing micro-auths then
$380-$920 electronics CNP purchases; NL/DE residential-proxy IPs; no
3-D Secure; common acceptance point NorthBridge Electronics (MCC 5732).
