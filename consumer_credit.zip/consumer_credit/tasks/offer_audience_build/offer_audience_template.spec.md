# Targeted-Offer Audience Report — Form Spec

**Form ID:** MC-OFFER-AUD
**Version:** 1.0
**Maintained by:** MeridianCard, Offers Analytics Desk

Field definitions for the audience + projection report the offer-analytics desk
delivers to a funding merchant for campaign sizing.

## Field-value discipline

Text values are literal; numbers stay numbers. The downstream eval matches
values literally.

## Fields

| Field | Type | Required | Notes |
|---|---|---|---|
| `offer_id` | string | yes | The funding merchant's offer identifier. |
| `merchant` | string | yes | Funding merchant name. |
| `category` | string | yes | Offer category (e.g., outdoor & apparel). |
| `audience_size` | number | yes | Total count of targetable cardmembers. |
| `audience_segments[].segment_label` | string | yes | Plain-language label for a coarse audience slice. |
| `audience_segments[].segment_size` | number | yes | Member count in the segment. |
| `projected_redemption_rate_pct` | number | yes | Projected offer redemption rate. |
| `projected_incremental_spend_usd` | number | yes | Projected incremental spend per redeemer. |
| `targeting_basis` | string | yes | Plain-language basis for the audience (category spend level). |
| `recommendation` | string | yes | Positioning recommendation for the campaign. |
