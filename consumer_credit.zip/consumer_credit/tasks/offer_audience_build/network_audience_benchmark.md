# OmniRail Network — Audience & Category Benchmark: Outdoor & Apparel (MCC 5655 / 5941)

Cross-issuer aggregate (anonymized), trailing 12 months. Member-shareable.

- Category card volume **+11% YoY**; premium/technical sub-segment **+19% YoY**.
- Category-wide **average ticket: $128**; median annual category spend **$390**.
- Benchmark **offer redemption rate** for a "$30 back on $150+" acquisition
  offer in this category: **6–9%**.
- Typical **incremental spend lift** among redeemers: **$70–$110** per redeemer
  over the offer window.

## Audience reporting standard (OmniRail member rule MR-AUD-07)

Audience insights shared with a funding merchant are **aggregate and
de-identified**. The network's de-identification standard for any reported
audience segment is a **minimum reportable cell size of 50 members** — segments
smaller than that are treated as re-identifying and are not reportable to an
external party.
