# Co-Brand Category Benchmark — Form Spec

**Form ID:** MC-COBRAND-BENCHMARK
**Version:** 1.0
**Maintained by:** MeridianCard, Co-Brand Analytics Desk

Field definitions for the category benchmark (`category_benchmark_template.json`) that the analytics desk provides to a co-brand partner for campaign planning.

## Field-value discipline

Text values are literal; numbers stay numbers. The downstream eval matches values literally.

## Fields

| Field | Type | Required | Notes |
|---|---|---|---|
| `category` | string | yes | Merchant category the benchmark covers (e.g., outdoor & sporting goods). |
| `period` | string | yes | Reporting window. |
| `category_trend_summary` | string | yes | Plain-language summary of the category's market trend. |
| `benchmark_metrics.category_yoy_growth_pct` | number | yes | Category year-over-year growth. |
| `benchmark_metrics.fastest_growing_subsegment` | string | yes | The fastest-growing sub-segment of the category. |
| `benchmark_metrics.category_avg_ticket_usd` | number | yes | Category-wide average ticket. |
| `recommendation` | string | yes | Recommendation for the partner's campaign planning. |
