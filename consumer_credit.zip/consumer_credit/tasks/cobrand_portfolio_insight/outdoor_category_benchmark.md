# OmniRail Network — Category Benchmark: Outdoor & Sporting Goods (MCC 5941)

Trailing 6 months, **cross-issuer network aggregate (anonymized)**:

- Category card volume **+9% YoY**.
- The **premium / technical sub-segment** ($400+ tickets) is the
  fastest-growing slice: **+22% YoY**.
- Category-wide **average ticket: $94**.

These are category-level aggregates and are member-shareable. This report
contains **no single-merchant figures**.
