# Collectability Triage — Form Spec

**Form ID:** CRS-DDQ-TRIAGE
**Version:** 1.0
**Maintained by:** Crescent Recovery Services

Field definitions for the per-account collectability triage (`triage_template.json`)
Crescent provides to a prospective purchaser evaluating a charged-off account.

## Field-value discipline
Text values are literal; numbers stay numbers. The downstream eval matches values literally.

## Fields

| Field | Type | Required | Notes |
|---|---|---|---|
| `account_id` | string | yes | The masked account number for the account under review. |
| `original_creditor` | string | yes | Creditor of record for this account. |
| `charged_off_amount_usd` | number | yes | Balance at charge-off. |
| `charge_off_date` | string | yes | Charge-off date (YYYY-MM-DD). |
| `last_payment_date` | string | yes | Date of the most recent payment on this account. |
| `last_payment_amount_usd` | number | yes | Amount of the most recent payment on this account. |
| `current_balance_usd` | number | yes | Current balance including post-placement accrual. |
| `payment_plan_status` | string | yes | Status of any active arrangement on this account (e.g., "active", "lapsed", "none"). |
| `contactability` | string | yes | Servicer's contactability rating for the account (e.g., "good", "limited"). |
| `collectability_assessment` | string | yes | Plain-language assessment of recovery likelihood for the buyer, and the basis for it (e.g., whether the delinquency appears situational or chronic). |
| `recommendation` | string | yes | Pricing / purchase recommendation note. |
